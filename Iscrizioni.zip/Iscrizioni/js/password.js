function togglePWD(){
    var pwd = document.querySelector('[name=password]');
    

    if(pwd.getAttribute('type')==='password'){
        pwd.setAttribute('type', 'text');
        document.getElementById('font').style.color ='#3d3d3d';
    }
    else{
        pwd.setAttribute('type', 'password');
        document.getElementById('font').style.color ='#f98012';
    }
    
}
function togglePWD2(){
    var pwdRep = document.querySelector('[name=passwordConf]');
    if(pwdRep.getAttribute('type')==='password'){
        pwdRep.setAttribute('type', 'text');
        document.getElementById('font2').style.color ='#3d3d3d';
    }
    else{
        pwdRep.setAttribute('type', 'password');
        document.getElementById('font2').style.color ='#f98012'
    }

}