<?php 
    require_once "controllers/authController.php"; 

    if(!isset($_SESSION["logged"])){
        header("location: https://progetti.itisgrassi.org/iscrizioni/login.php");
        exit;
    }
    $emailCheckLvl= "'". $_COOKIE["email"]."'";
    $sql = "SELECT livello FROM tbAccount WHERE user=$emailCheckLvl";
    $resultsd1 = mysqli_query($r, $sql);
    $row = mysqli_fetch_assoc($resultsd1);
    if ($row['livello'] == 2){
        header('location: https://progetti.itisgrassi.org/iscrizioni/gestionale.php');
    }
    elseif($row['livello'] == 0){
        header('location: https://progetti.itisgrassi.org/iscrizioni/homepage.php');
    }

    if(isset($_POST['upload-btn'])){
        $nome = trim($_POST['name']);
        $cognome = trim($_POST['surname']);
        $ddnascita = trim($_POST['ddnascita']);
        $codFiscale = trim($_POST['codFiscale']);
        $citta = trim($_POST['citta']);
        $cap = trim($_POST['cap']);
        $cittadinanza = trim($_POST['cittadinanza']);

        if(empty($nome)){
            $errors['name'] = "Inserire un nome";
        }
        if(empty($cognome)){
            $errors['surname'] = "Inserire un cognome";
        }
        if(empty($ddnascita)){
            $errors['ddnascita'] = "Inserire la data di nascita";
        }
        if(empty($codFiscale)){
            $errors['codFiscale'] = "Inserire il codice fiscale";
        }
        if(strlen(($codFiscale)) != 16){
            $errors['codFiscale'] = "Il formato del codice fiscale non è valido";
        }
        if(empty($citta)){
            $errors['citta'] = "Inserire la città";
        }
        if(empty($cap)){
            $errors['cap'] = "Inserire il cap";
        }
        if(strlen(($codFiscale)) != 5){
            $errors['cap'] = "Il formato del CAP non è valido";
        }
        if(empty($cittadinanza)){
            $errors['cittadinanza'] = "Inserire la cittadinanza";
        }

        $codFiscaleQuery = "SELECT codiceFiscale FROM tbAnagrafica where user=? LIMIT 1";
        $stmt = $r->prepare($codFiscaleQuery);
        $stmt->bind_param('s', $codFiscale);
        $stmt->execute();
        $result = $stmt->get_result();
        $userCount = $result->num_rows;
        $stmt->close();
        if ($userCount > 0)
        {
            $errors['codFiscale'] = "Il codice fiscale è già utilizzato in un altro account";
        }



        if(count($errors) === 0){
            //inserimento
        }
    }

?>
