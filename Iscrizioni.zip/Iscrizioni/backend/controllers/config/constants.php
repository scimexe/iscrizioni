<?php
    define("EMAIL","andre.scimeca03@gmail.com");
    define("PASSWORD","tzlreaqrymytgofr");
    define("MAILNAME","Andrea Scimeca");
?>