<?php
    session_start();
    require "../admin/newCDB.php";
    require_once "emailController.php";

    $errors = array();
    $email = "";

    $db = new CDB();
    $r = $db->connessione();

    function verifyUser($token)
    {
        global $r;
        mysqli_escape_string($r, $token);
        $sql = "SELECT * FROM tbAccount WHERE token='$token' LIMIT 1";
        $result = mysqli_query($r,$sql);

        if (mysqli_num_rows($result) > 0)
        {
            $user = mysqli_fetch_assoc($result);
            $update_query = "UPDATE tbAccount SET livello=1 WHERE token='$token'";

            if (mysqli_query($r,$update_query))
            {
                // LOG IN
                $_SESSION['email'] = $user['email'];
                $_SESSION['verified'] = 1;
                $_SESSION['message'] = "La tua email è ora verificata!";
                $_SESSION['alert-class'] = "alert-success";
                header("location: https://progetti.itisgrassi.org/iscrizioni/homepage.php");
                exit();
            }
        }
        else
        {
            echo "User not found";
        }
    }

    if (isset($_GET['logout']))
    {
        session_destroy();
        unset($_SESSION['email']);
        unset($_SESSION['password']);
        unset($_SESSION['verified']);
        unset($_SESSION['logged']);
        setcookie('email', "", -1);
        header('location: https://progetti.itisgrassi.org/iscrizioni/login.php');
        exit();
    }
?>