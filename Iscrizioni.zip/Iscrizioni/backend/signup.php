<?php
    require_once 'controllers/authController.php';

    if(isset($_POST['signup-btn']))
    {
        $email = $_POST['email'];
        $password = $_POST['password'];
        $passwordConf = $_POST['passwordConf'];

        if(!filter_var($email , FILTER_VALIDATE_EMAIL))
        {
            $errors['email'] = "Indirizzo email non valido";
        }
        if(empty($email))
        {
            $errors['email'] = "Inserire un indirizzo email";
        }
        if(strlen($email)>=100)
        {
            $errors['email'] = "Lunghezza indirizzo mail non valida";
        }
        if(empty($password) || strlen($password)<8)
        {
            $errors['password'] = "Inserire password di almeno 8 caratteri";
        }
        if($passwordConf !== $password)
        {
            $errors['password'] = "Le password inserite non corrispondono";
        }
        
        $emailQuery = "SELECT * FROM tbAccount where user=? LIMIT 1";
        $stmt = $r->prepare($emailQuery);
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $userCount = $result->num_rows;
        $stmt->close();
        if ($userCount > 0)
        {
            $errors['email'] = "L'indirizzo email è già utilizzato in un altro account";
        }
        if (count($errors) === 0)
        {
            $password = password_hash($password, PASSWORD_DEFAULT);
            $token = bin2hex(random_bytes(50));
            $verified = 0;

            $sql = "INSERT INTO tbAccount (user, passwd, livello, token) VALUES (?, ?, ?, ?)";
            $stmt = $r->prepare($sql);
            $stmt->bind_param('ssis', $email, $password, $verified, $token);
            if ($stmt->execute())
            {   // login user
                $_SESSION['email'] = $email;
                $_SESSION['verified'] = $verified;

                send_Mail($email, $token);

                // flash message
                $_SESSION['message'] = "Ora hai eseguito l'accesso";
                $_SESSION['alert-class'] = "alert-success";
                setcookie('email', $email, time() + 86400);
                header('location: https://progetti.itisgrassi.org/iscrizioni/homepage.php');
                
                exit();
            }
            else
            {
                echo $stmt->error;
                $errors['db_error'] = "Database error: failed to register";
            }
        }
    }
?>


