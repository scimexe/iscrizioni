<?php
    require_once '../backend/login.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Login</title>
        <script src="https://progetti.itisgrassi.org/iscrizioni/js/validation-login.js"> </script>
        <script src="https://progetti.itisgrassi.org/iscrizioni/js/password.js"> </script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <link rel="stylesheet" href="https://progetti.itisgrassi.org/iscrizioni/css/style.css">
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 offset-md-4 form-div login">
                    <form name ="formLogin" action="login.php" method="post" onsubmit="return validateForm()">
                        <h3 class="text-center">Login</h3>
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <?php foreach($errors as $error): ?>
                                    <li><?php echo $error; ?></li>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        
                            <div class="form-group">
                                <!--<label for="email">Email</label>-->
                                <div class="input-container">
                                    <input type="text" id ="email" name="email" class="form-control form-control-lg" value="<?php echo $email; ?>" placeholder="Email" border:0>
                                </div>
                            </div>
                        <div class="form-group">
                            <div class="input-container">
                                
                                <!--<label for="password">Password</label>-->
                                <input type="password" id ="passwordLogin" name="password" class="form-control form-control-lg" placeholder="Password">
                                <span>
                                    <i class="material-icons visibility" id="font" onclick="togglePWD()">visibility</i>
                                </span>
                                
                            </div>        
                        </div>
                        <div class="form-group text-center">
                            <button type="submit" name="login-btn" class="btn btn-primary btn-block btn-lg btn">Login</button>
                        </div>
                        
                        <p class="text-center">Non sei ancora registrato? <a href="signup.php" class="signin-txt">Registrati</a></p>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>