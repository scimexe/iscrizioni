<?php
    require_once '../backend/signup.php';
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Registrazione account</title>
        <script src="https://progetti.itisgrassi.org/iscrizioni/js/validation-signup.js"></script>
        <script src="https://progetti.itisgrassi.org/iscrizioni/js/password.js"> </script>
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://progetti.itisgrassi.org/iscrizioni/css/style.css">
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 offset-md-4 form-div signup">
                    <form name = "formSignUp" action="signup.php" method="post" onsubmit="return validateForm()">
                        <h3 class="text-center">Registrazione</h3>

                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <?php foreach($errors as $error): ?>
                                    <li><?php echo $error; ?></li>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                        <div class="form-group">
                            <div class="input-container">
                            <!--<label for="email">Indirizzo Email</label>-->
                                <input type="email" id= 'email' name="email" class="form-control form-control-lg" value="<?php echo $email; ?>" placeholder="Indirizzo Email">
                            </div>    
                        </div>
                        <div class="form-group">
                             <!--<label for="password">Password</label>-->
                            <div class="input-container"> 
                                <input type="password" id="passwordSignUp" name="password" class="form-control form-control-lg" placeholder="Password">
                                <span>
                                        <i class="material-icons visibility" id="font" onclick="togglePWD()">visibility</i>
                                </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-container">
                                <input type="password" id='passwordRep' name="passwordConf" class="form-control form-control-lg" placeholder="Ripeti password">
                                <span>
                                        <i class="material-icons visibility" id="font2" onclick="togglePWD2()">visibility</i>
                                    </span>
                            </div>        
                        </div>
                        <div class="form-group text-center">
                            <button type="submit" name="signup-btn" class="btn btn-primary btn-block btn-lg btn">Registrati</button>
                        </div>
                        <p class="text-center">Sei già registrato? <a href="login.php" class="signin-txt">Accedi</a></p>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>