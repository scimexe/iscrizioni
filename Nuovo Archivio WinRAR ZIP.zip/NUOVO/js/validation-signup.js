function validateForm(){
    var user = document.forms['formSignUp']['email'];
    var pwd = document.forms['formSignUp']['password'];
    var pwdRep = document.forms['formSignUp']['passwordConf'];
    error = 0;

    if ((user.value === '') || (user.value == null)){
        user.style.border="2px solid red";
        error++;
    }
    if ((pwd.value === '') || (pwd.value == null)){
        pwd.style.border="2px solid red";
        error++;
    }
    if ((pwdRep.value === '') || (pwdRep.value == null)){
        pwdRep.style.border="2px solid red";
        error++;
    }
    if (error > 0){
        return false;
    }
}