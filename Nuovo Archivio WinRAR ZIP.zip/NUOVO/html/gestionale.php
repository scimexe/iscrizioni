<?php
    require_once '../backend/gestionale.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionale</title>
</head>
<body>
    
    <div class="text-center">
        <?php 
        if ($row['livello'] != 2):
            header('location: not-permitted.php'); 
        ?>
         <a href="homepage.php?logout=1" class="logout">Torna all'homepage</a>
         <?php endif; ?>
         <a href="homepage.php?logout=1" class="logout">Logout</a>
    </div>
</body>
</html>