<?php 
    require_once "controllers/authController.php"; 

    if(!isset($_SESSION["logged"])){
        header("location: login.php");
        exit;
    }
    $emailCheckLvl= "'". $_COOKIE["email"]."'";
    $sql = "SELECT livello FROM tbAccount WHERE user=$emailCheckLvl";
    $resultsd1 = mysqli_query($r, $sql);
    $row = mysqli_fetch_assoc($resultsd1);
    if ($row['livello'] == 2){
        header('location: ../html/gestionale.php');
    }
    elseif($row['livello'] == 0){
        header('location: ../html/homepage.php');
    }

    if(isset($_POST['upload-btn'])){
        $name = trim($_POST['name']);
        $surname = trim($_POST['surname']);
        $ddnascita = trim($_POST['ddnascita']);
        $codFiscale = trim($_POST['codFiscale']);
        echo $name . $surname . $ddnascita . $codFiscale;
    }

?>
