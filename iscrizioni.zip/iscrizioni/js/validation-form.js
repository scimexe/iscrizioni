function validateForm(){
    
    var name = document.forms["formAnagrafica"]["name"];
    var surname = document.forms["formAnagrafica"]["surname"];
    var ddnascita = document.forms["formAnagrafica"]["ddnascita"];
    var codFiscale = document.forms["formAnagrafica"]["codFiscale"];
    var citta = document.forms["formAnagrafica"]["citta"];
    var cap = document.forms["formAnagrafica"]["cap"];
    var cittadinanza = document.forms["formAnagrafica"]["cittadinanza"];
    var error = 0;

    if ((name.value === '') || (name.value == null)){
        name.style.border="2px solid red";
        error++;
    }
    if ((surname.value === '') || (surname.value == null)){
        surname.style.border="2px solid red"; 
        error++;
    }
    if ((ddnascita.value === '') || (ddnascita.value == null)){
        ddnascita.style.border="2px solid red";         
        error++;
    }
    if ((codFiscale.value === '') || (codFiscale.value == null) || (codFiscale.value.length != 16)){
        codFiscale.style.border="2px solid red"; 
        error++;
    }
    if ((citta.value === '') || (citta.value == null)){
        citta.style.border="2px solid red";         
        error++;
    }
    if ((cap.value === '') || (cap.value == null) || cap.value.length !=5 || isNaN(cap.value)){
        cap.style.border="2px solid red"; 
        error++;
    }
    if ((cittadinanza.value === '') || (cittadinanza.value == null)){
        cittadinanza.style.border="2px solid red";         
        error++;
    }
    if (error > 0){
        return false;
    }
    
   
    
}
    

    
    
 
