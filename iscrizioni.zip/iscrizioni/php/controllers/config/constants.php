<?php
    define("EMAIL","");
    define("PASSWORD","");
    define("MAILNAME","");
?>