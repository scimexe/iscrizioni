<?php require_once "controllers/authController.php"; ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Login</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="/css/style.css">
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 offset-md-4 form-div login">
                    <form action="login.php" method="post">
                        <h3 class="text-center">Login</h3>
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <?php foreach($errors as $error): ?>
                                    <li><?php echo $error; ?></li>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                        <!-- 
                            <div class="alert alert-danger">
                                <li>Inserisci i valori in tutti i campi</li>
                            </div>
                        -->

                        <!-- Div per ogni campo di inserimento della registrazione -->
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" name="email" class="form-control form-control-lg" value="<?php echo $email; ?>">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" name="password" class="form-control form-control-lg">
                        </div>
                        <div class="form-group text-center">
                            <button type="submit" name="login-btn" class="btn btn-primary btn-block btn-lg btn">Login</button>
                        </div>
                        <!-- ||||||||||||||||||||||||||||||||||||||||||||||||||||| -->

                        <p class="text-center">Non sei ancora registrato? <a href="signup.php" class="signin-txt">Registrati</a></p>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>