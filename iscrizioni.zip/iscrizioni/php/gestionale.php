<?php 
    require_once "controllers/authController.php";
    
    if(!isset($_SESSION["logged"])){
        header("location: login.php");
        exit;
    }
    $emailCheckLvl= "'". $_COOKIE["email"]."'";
    if(empty($_COOKIE["email"])){
        header('location: login.php');
    }
    $sql = "SELECT livello FROM tbAccount WHERE user=$emailCheckLvl";
    $resultsd1 = mysqli_query($r, $sql);
    $row = mysqli_fetch_assoc($resultsd1);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionale</title>
</head>
<body>
    
    <div class="text-center">
        <?php 
        if ($row['livello'] != 2):
            echo "Non hai i permessi per accedere a quest'area"; 
        ?>
         <a href="homepage.php?logout=1" class="logout">Torna all'homepage</a>
         <?php endif; ?>
         <a href="homepage.php?logout=1" class="logout">Logout</a>
    </div>
</body>
</html>
