<?php 
    require_once "controllers/authController.php"; 

    if(!isset($_SESSION["logged"])){
        header("location: login.php");
        exit;
    }
    $emailCheckLvl= "'". $_COOKIE["email"]."'";
    $sql = "SELECT livello FROM tbAccount WHERE user=$emailCheckLvl";
    $resultsd1 = mysqli_query($r, $sql);
    $row = mysqli_fetch_assoc($resultsd1);
    if ($row['livello'] == 2){
        header('location: gestionale.php');
    }
    elseif($row['livello'] == 0){
        header('location: homepage.php');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registrazione anagrafica</title>
</head>
<body>
    <p>ciao</p>
    <?php echo $_SESSION["email"]; ?>
     <div class="text-center">
         <a href="homepage.php?logout=1" class="logout">Logout</a>
    </div>
</body>
</html>