<?php
    require '../backend/homepage.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Homepage</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="../css/style.css">
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 offset-md-4 form-div ">
                    <?php if(isset($_SESSION['message'])): ?>
                        <div class="alert <?php echo $_SESSION['alert-class']; ?>">
                            <?php 
                                echo $_SESSION['message']; 
                                unset($_SESSION['message']);
                                unset($_SESSION['alert-class']);
                            ?>
                        </div>
                    <?php endif; ?>
                    <div class="text-center">
                        <h3>Benvenuto,<br><?php echo $_COOKIE['email'] ?></h3>
                    </div>
                    <?php //if($_SESSION['verified'] == 0): 
                        $emailCheckLvl= "'". $_COOKIE['email']."'";
                        $sql = "SELECT livello FROM tbAccount WHERE user=$emailCheckLvl";
                        $resultsd1 = mysqli_query($r, $sql);
                        $row = mysqli_fetch_assoc($resultsd1);
                        if($row['livello'] == 0):
                        ?>
                        <div class="alert alert-warning">Per poter proseguire devi verificare il tuo account accedendo all'indirizzo email
                            che hai inserito in fase di registrazione (<strong><?php echo $_SESSION['email'] ?></strong>) e cliccare sul link.
                        </div>
                    <?php endif; ?>
                    <div class="text-center">
                        
                    </div>
                    <?php if($_SESSION['verified'] !== 0): ?>
                    <div class="text-center">
                            <a href="../html/anagrafica.php">
                                <div class="form-group text-center">
                                <button type="submit" name="signup-btn" class="btn btn-primary btn-block btn-lg btn">Continua la registrazione cliccando qua!</button>
                                <br>
                                <a href="homepage.php?logout=1" class="logout">Logout</a>
                            </a>
                        </div>
                     </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </body>
</html>