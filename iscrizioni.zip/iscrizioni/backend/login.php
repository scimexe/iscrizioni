<?php require_once "controllers/authController.php"; 

    if(isset($_POST['login-btn']))
        {
            $email = $_POST['email'];
            $password = $_POST['password'];
            if(empty($email))
            {
                $errors['email'] = "Inserire un indirizzo email";
            }
            if(!filter_var($email , FILTER_VALIDATE_EMAIL))
            {
                $errors['email'] = "Indirizzo email non valido";
            }
            if(empty($password))
            {
                $errors['password'] = "Inserire Password";
            }

            if(count($errors) === 0)
            {

                $sql = "SELECT * FROM tbAccount WHERE user=? LIMIT 1";
                $stmt = $r->prepare($sql);
                $stmt->bind_param('s', $email);
                $stmt->execute();
                $result = $stmt->get_result();
                $user = $result->fetch_assoc();
                if ($user == null){
                    $errors['email'] = "Indirizzo email inesistente";
                }
                else{
                    
                    if(password_verify($password, $user['passwd']))
                    {
                        
                        // login user
                        
                        $_SESSION['email'] = $user["email"];
                        $_SESSION['verified'] = $user["verified"];
                        $emailApici = '"'.$email.'"';
                        $sql = "SELECT livello FROM tbAccount WHERE livello = 0 and user=$emailApici";
                        $result = $r->query($sql);
                        $row = $result->fetch_all(MYSQLI_ASSOC);
                        $result -> free_result();
                        if ($result == 0){
                            send_Mail($email, $token);
                        }

                        // flash message
                        $_SESSION['message'] = "Ora hai eseguito l'accesso";
                        $_SESSION['alert-class'] = "alert-success";
                        $_SESSION['email'] = $email;
                        $_SESSION["logged"] = true;
                        setcookie('email', $email, time() + 86400);
                        header('location: ../html/homepage.php');
                        exit();
                    }
                    else
                    {
                        $errors["login-fail"] = "Credenziali errate";
                    }
                }
            }
        }
?>
