<?php 
    require_once "controllers/authController.php"; 

    if(!isset($_SESSION["logged"])){
        header("location: login.php");
        exit;
    }
    $emailCheckLvl= "'". $_COOKIE["email"]."'";
    $sql = "SELECT livello FROM tbAccount WHERE user=$emailCheckLvl";
    $resultsd1 = mysqli_query($r, $sql);
    $row = mysqli_fetch_assoc($resultsd1);
    if ($row['livello'] == 2){
        header('location: gestionale.php');
    }
    elseif($row['livello'] == 0){
        header('location: homepage.php');
    }

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8"> 
        <title>Registrazione anagrafica</title>
        <script src="../js/validation.js"> </script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="header"> 
            <div class ="img">
                <img src="ITTSGrassi360x150.png">
            </div>
        
            <p class = "right-text" id= "h3benvenuto">Benvenuto <?php echo $_SESSION["email"]; ?></p>
            <p class="right-text-logout"><a href="homepage.php?logout=1" class="signin-txt">Logout</a></p>
            <!--<p class="text-center right-text"><a href="homepage.php?logout=1" class="signin-txt">Logout</a></p>-->
            <h3 class="h3">Prosegui ora con la registrazione dell'anagrafica</h3>
        </div>
        <div class="container">
            <div class="row">
                        
                        <div class="error"></div>
                        <form id = "form" name= "formAnagrafica" action="<?php echo $_SERVER['PHP_SELF']?>" onsubmit="return valifdateForm()" method="post">
                            <div class="form-group">
                                <label for="name">Nome</label>
                                <input type="text" name="name" placeholder="Inserire nome" class="form-control form-control-lg " >
                            </div>
                            <div class="form-group">
                                <label for="name">Cognome</label>
                                <input type="text" name="surname" placeholder="Inserire cognome" class="form-control form-control-lg ">
                            </div>
                            <div class="form-group">
                                <label for="ddnascita">Data di nascita</label>
                                <input type="date" name="ddnascita" class="form-control form-control-lg ">
                            </div>
                            <div class="form-group">
                                <label for="codFiscale">Codice Fiscale</label>
                                <input type="text" name="codFiscale" placeholder="Inserire codice fiscale" class="form-control form-control-lg "maxlength="16" >
                            </div>
                            <div class="form-group">
                                <label for="citta">Città</label>
                                <input type="text" name="citta" placeholder="Inserire città di residenza" class="form-control form-control-lg">
                            </div>
                            <div class="form-group">
                                <label for="cap">Cap</label>
                                <input type="text" name="cap" placeholder="Inserire CAP" class="form-control form-control-lg" maxlength="5">
                            </div>
                            <div class="form-group">
                                <label for="nazione">Nazione</label>
                                <?php require "nazioni.html"?>
                            </div>
                            <div class="form-group">
                                <label for="cittadinanza">Cittadinanza</label>
                                <input type="text" name="cittadinanza" placeholder="Inserire cittadinanza" class="form-control form-control-lg">
                            </div>
                            <div class="form-group">
                                <label for="file">File da caricare</label>
                                <input type="file" name="file" class="form-control form-control-lg">
                            </div>
                            <div class="form-group text-center">
                                <button type="submit" name="upload-btn" class="btn btn-primary btn-block btn-lg btn">Invia i tuoi dati</button>
                            </div>
                            
                        </form>
                    <!-- <p class="text-center"><a href="homepage.php?logout=1" class="signin-txt">Logout</a></p>     -->
            </div>
        </div>
    </body>
</html>