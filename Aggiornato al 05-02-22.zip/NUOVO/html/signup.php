<?php
    require_once '../backend/signup.php';
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Registrazione account</title>
        <script src="../js/validation-signup.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="../css/style.css">
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 offset-md-4 form-div signup">
                    <form name = "formSignUp" action="signup.php" method="post" onsubmit="return validateForm()">
                        <h3 class="text-center">Registrazione</h3>

                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <?php foreach($errors as $error): ?>
                                    <li><?php echo $error; ?></li>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                        <div class="form-group">
                            <label for="email">Indirizzo Email</label>
                            <input type="email" name="email" class="form-control form-control-lg" value="<?php echo $email; ?>">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" name="password" class="form-control form-control-lg">
                        </div>
                        <div class="form-group">
                            <label for="passwordConf">Ripeti Password</label>
                            <input type="password" name="passwordConf" class="form-control form-control-lg">
                        </div>
                        <div class="form-group text-center">
                            <button type="submit" name="signup-btn" class="btn btn-primary btn-block btn-lg btn">Registrati</button>
                        </div>
                        <p class="text-center">Sei già registrato? <a href="login.php" class="signin-txt">Accedi</a></p>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>