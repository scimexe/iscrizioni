function validateForm(){
    var user = document.forms['formLogin']['email'];
    var pwd = document.forms['formLogin']['password'];
    error = 0;
    
    if ((user.value === '') || (user.value == null)){
        user.style.border="2px solid red";
        error++;
    }
    if ((pwd.value === '') || (pwd.value == null)){
        pwd.style.border="2px solid red";
        error++;
    }
    if (error > 0){
        return false;
    }
}