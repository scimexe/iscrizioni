<?php 
    require_once "controllers/authController.php";
    
    if(!isset($_SESSION["logged"])){
        header("location: login.php");
        exit;
    }
    $emailCheckLvl= "'". $_COOKIE["email"]."'";
    if(empty($_COOKIE["email"])){
        header('location: login.php');
    }
    $sql = "SELECT livello FROM tbAccount WHERE user=$emailCheckLvl";
    $resultsd1 = mysqli_query($r, $sql);
    $row = mysqli_fetch_assoc($resultsd1);
?>

