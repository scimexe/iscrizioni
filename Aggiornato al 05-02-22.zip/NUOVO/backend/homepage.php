<?php 
    require_once "controllers/authController.php";

    if(!isset($_SESSION["logged"])){
        header("location: ../html/login.php");
        
    }

    if (isset($_GET['token']))
    {
        $token = $_GET['token'];
        verifyUser($token);
    }
    $emailCheckLvl= "'". $_COOKIE["email"]."'";
    $sql = "SELECT livello FROM tbAccount WHERE user=$emailCheckLvl";
    $resultsd1 = mysqli_query($r, $sql);
    $row = mysqli_fetch_assoc($resultsd1);

    if ($row['livello'] == 2){
        header("location: ../html/gestionale.php");
    }
    
?>
