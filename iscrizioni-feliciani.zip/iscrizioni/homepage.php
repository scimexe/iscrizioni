<?php 
    require_once "controllers/authController.php";

    if (isset($_GET['token']))
    {
        $token = $_GET['token'];
        verifyUser($token);
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Homepage</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 offset-md-4 form-div login">
                    <?php if(isset($_SESSION['message'])): ?>
                        <div class="alert <?php echo $_SESSION['alert-class']; ?>">
                            <?php 
                                echo $_SESSION['message']; 
                                unset($_SESSION['message']);
                                unset($_SESSION['alert-class']);
                            ?>
                        </div>
                    <?php endif; ?>
                    <div class="text-center">
                        <h3>Benvenuto, <?php echo $_SESSION['email'] ?></h3>
                    </div>
                    <?php if($_SESSION['verified'] === 0): ?>
                        <div class="alert alert-warning">Per poter proseguire devi verificare il tuo account accedendo all'indirizzo email
                            che hai inserito in fase di registrazione (<strong><?php echo $_SESSION['email'] ?></strong>) e cliccare sul link.
                        </div>
                    <?php endif; ?>
                    <div class="text-center">
                        <a href="homepage.php?logout=1" class="logout">Logout</a>
                    </div>
                    <?php if($_SESSION['verified'] !== 0): ?>
                        <div class="text-center">
                            <!--non funziona l'href, RISOLVI--> 
                            <button class="btn btn-block btn-lg btn-primary form-group" name="goon-btn" href="end-signup.php">>Continua la registrazione cliccando qua!</button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </body>
</html>