<?php
    define("EMAIL","gabrielefeliciani2003@gmail.com");
    define("PASSWORD","mznmypuljujctgpz");
    define("MAILNAME","Gabriele Feliciani");
?>