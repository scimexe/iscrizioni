<?php
    require 'vendor/autoload.php';
    require_once "config/constants.php";

    $transport = (new Swift_SmtpTransport("smtp.gmail.com",465,"ssl"))
        ->setUsername(EMAIL)
        ->setPassword(PASSWORD);

    $mailer = new Swift_Mailer($transport);

    function send_Mail($email, $token)
    {
        global $mailer;

        $body=' <!DOCTYPE html>
        <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>Verifica account</title>
            </head>
            <body>
                <div class="wrapper">
                    <p>
                        Grazie per aver effettuato la registrazione sul sito. Clicca sul link qua sotto per verificare il tuo account.
                    </p>
                    <a href="http://localhost/iscrizioni/homepage.php?token=' . $token .'">
                        Verifica il tuo account cliccando qui!
                    </a>
                </div>
            </body>
        </html>
        ';

        $message = (new Swift_Message("Verifica Account"))
            ->setFrom([EMAIL => MAILNAME])
            ->setTo($email)
            ->setBody($body, "text/html");

        $result = $mailer->send($message);
    }
?>