<?php require_once "controllers/authController"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registrazione anagrafica</title>
</head>
<body>
    <p>ciao</p>
</body>
</html>